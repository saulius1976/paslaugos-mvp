"use client";

import { useState } from "react";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";

interface Request {
  title: string;
  location: string;
  budget: string;
  description: string;
}

interface Offer {
  provider: string;
  message: string;
  price: string;
}

interface User {
  name: string;
  email: string;
  isProvider: boolean;
}

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [budget, setBudget] = useState("");
  const [description, setDescription] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [requests, setRequests] = useState<Request[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);

  const handleLogin = () => {
    const name = prompt("Įveskite savo vardą");
    const email = prompt("El. paštas");
    const isProvider = confirm("Ar esate paslaugų teikėjas?");
    if (name && email) {
      setUser({ name, email, isProvider });
    }
  };

  const handleSubmit = () => {
    if (title && location && budget && description) {
      const newRequest = { title, location, budget, description };
      setRequests([...requests, newRequest]);
      setSubmitted(true);
    } else {
      alert("Prašome užpildyti visus laukus");
    }
  };

  const handleOffer = () => {
    if (!user || !user.isProvider) {
      alert("Tik prisijungę paslaugų teikėjai gali pateikti pasiūlymus");
      return;
    }
    const price = prompt("Kokia jūsų siūloma kaina (€)?");
    const message = prompt("Trumpa žinutė užsakovui");
    if (price && message) {
      setOffers([...offers, { provider: user.name, price, message }]);
    }
  };

  return (
    <div className="max-w-3xl mx-auto mt-10 p-4">
      <h1 className="text-3xl font-bold mb-6">Paslaugų platforma</h1>

      {!user ? (
        <div className="mb-6">
          <Button onClick={handleLogin}>Prisijungti</Button>
        </div>
      ) : (
        <div className="mb-6 text-sm text-gray-600">
          Prisijungęs kaip: <strong>{user.name}</strong> ({user.isProvider ? "Paslaugų teikėjas" : "Užsakovas"})
        </div>
      )}

      {user && !user.isProvider && !submitted && (
        <Card>
          <CardContent className="space-y-4 pt-6">
            <Input
              placeholder="Užduoties pavadinimas (pvz., Baldų surinkimas)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <Input
              placeholder="Vieta (miestas, rajonas)"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
            <Input
              placeholder="Biudžetas (€)"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
            />
            <Textarea
              placeholder="Išsamiai aprašykite, kokios paslaugos reikia"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <Button onClick={handleSubmit}>Pateikti užklausą</Button>
          </CardContent>
        </Card>
      )}

      {submitted && (
        <div className="bg-green-100 p-6 rounded-xl text-green-800 shadow mb-6">
          <h2 className="text-xl font-semibold mb-2">Užklausa pateikta sėkmingai!</h2>
          <p>Meistrai galės netrukus pateikti pasiūlymus.</p>
        </div>
      )}

      {requests.length > 0 && (
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-4">Visos užklausos</h2>
          {requests.map((req, idx) => (
            <Card key={idx} className="mb-4">
              <CardContent className="space-y-2 pt-4">
                <p><strong>{req.title}</strong> – {req.location}</p>
                <p>Biudžetas: €{req.budget}</p>
                <p>{req.description}</p>
                {user?.isProvider && (
                  <Button onClick={handleOffer}>Pateikti pasiūlymą</Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {offers.length > 0 && (
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-4">Gauti pasiūlymai</h2>
          {offers.map((offer, idx) => (
            <Card key={idx} className="mb-4">
              <CardContent className="space-y-2 pt-4">
                <p><strong>{offer.provider}</strong> siūlo €{offer.price}</p>
                <p>Žinutė: {offer.message}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
